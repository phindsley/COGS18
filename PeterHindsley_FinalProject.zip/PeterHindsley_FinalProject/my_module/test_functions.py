"""Test functions."""
from functions import is_question, remove_punctuation, end_chat

def test_is_question():
    assert is_question == None
# Test out test
assert callable(test_is_question)

def test_remove_punctuation():
    assert remove_punctuation == None
    
assert callable(test_remove_punctuation)

def test_end_chat():
    assert remove_punctuation == None
    
assert callable(test_remove_punctuation)